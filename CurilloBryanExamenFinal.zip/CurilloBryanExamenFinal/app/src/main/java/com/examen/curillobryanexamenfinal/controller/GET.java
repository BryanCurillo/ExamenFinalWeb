package com.examen.curillobryanexamenfinal.controller;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.examen.curillobryanexamenfinal.R;

import org.json.JSONArray;

import java.util.ArrayList;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.examen.curillobryanexamenfinal.model.placeHolder;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GET extends AppCompatActivity {

    ArrayList<String> datos = new ArrayList<>();
    ArrayAdapter arrayAdapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get);

        listView=findViewById(R.id.listNoticias);
        arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, datos);
        listView.setAdapter(arrayAdapter);
        obtenerDatos();
    }

    private void obtenerDatos() {
        String url = "https://jsonplaceholder.typicode.com/posts";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //manejo de JSON
                manejarJson(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG);
            }
        });
        //REALIZO LA PETICION DE TIPO GET AL WEB SERVICE
        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void manejarJson(JSONArray jsonArray) {
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = null;

            try {
                jsonObject = jsonArray.getJSONObject(i);
                placeHolder placeHolder = new placeHolder();
                placeHolder.setId(jsonObject.getInt("id"));
                placeHolder.setUserId(jsonObject.getInt("userId"));
                placeHolder.setTitulo(jsonObject.getString("title"));
                placeHolder.setCuerpo(jsonObject.getString("body"));

                //Guardamos en ArrayList<Publicacion> toda la info.
                datos.add("\n> Titulo: "+placeHolder.getTitulo()+"\n\n Cuerpo: "+placeHolder.getCuerpo()+"\n");
//                datos.add(placeHolder.getCuerpo());

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        arrayAdapter.notifyDataSetChanged();
    }
}