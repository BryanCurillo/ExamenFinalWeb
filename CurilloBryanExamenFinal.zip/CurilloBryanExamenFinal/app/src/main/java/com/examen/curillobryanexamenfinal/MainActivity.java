package com.examen.curillobryanexamenfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.examen.curillobryanexamenfinal.controller.GET;
import com.examen.curillobryanexamenfinal.controller.POST;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnGet = findViewById(R.id.btnGet);
    }
    public void openGet(View view){
        Intent intent= new Intent(this, GET.class);

        startActivity(intent);
    }

    public void openPost(View view){
        Intent intent= new Intent(this, POST.class);

        startActivity(intent);
    }
}